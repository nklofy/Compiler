package Parser.TypeSys;

public enum Type_SgStmt {
	CtrFlw,
	VarAssign,
	CalcExp;
}
