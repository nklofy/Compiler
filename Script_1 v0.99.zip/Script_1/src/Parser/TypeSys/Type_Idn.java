package Parser.TypeSys;

public enum Type_Idn {
	t_type,t_obj,t_func;
}
