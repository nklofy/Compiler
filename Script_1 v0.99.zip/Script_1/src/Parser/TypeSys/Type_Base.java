package Parser.TypeSys;

public enum Type_Base {
	t_int,
	t_double,
	t_bool,
	t_char,
	t_string
}
