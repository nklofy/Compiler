package Parser.TypeSys;

public enum Type_Stmt {
	SgStmt,
	VarDef,
	IfExp,
	WhileExp,
	FuncDef;
}
