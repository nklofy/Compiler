every one can use the source code freely.
please see instruction.
--------------------------------------------------

lex analyzer/ auto-machine generator

tokenizer

LR(1) parser generator

LR(1) parser

Interpreter
